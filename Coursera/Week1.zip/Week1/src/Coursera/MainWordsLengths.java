package Coursera;

// import edu.duke.FileResource;

public class MainWordsLengths {

	public static void main(String[] args) {

		WordLengths wordLengths = new WordLengths();
		wordLengths.testCountWordLengths();
		

	}

}
